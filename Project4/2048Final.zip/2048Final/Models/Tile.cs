﻿namespace _2048Final.Models
{
    public class Tile
    {
        /// <summary>
        /// value of the tile (0 if empty)
        /// </summary>
        public int Value { get; set; }

        /// <summary>
        /// Indicates whether the tile has been merged in the current move
        /// </summary>
        public bool IsMerged { get; set; }

        /// <summary>
        /// Tile constructor
        /// </summary>
        /// <param name="value"></param>
        public Tile(int value = 0)
        {
            Value = value;
        }

        /// <summary>
        /// string representation of the tile's CSS class based on its value
        /// </summary>
        public string CssClass => Value switch
        {
            2 => "tile-2",
            4 => "tile-4",
            8 => "tile-8",
            16 => "tile-16",
            32 => "tile-32",
            64 => "tile-64",
            128 => "tile-128",
            256 => "tile-256",
            512 => "tile-512",
            1024 => "tile-1024",
            2048 => "tile-2048",
            _ => "tile-empty"
        };
    }
}
