﻿namespace _2048Final.Models
{
    public class GameBoard
    {
        /// <summary>
        /// A list of constructors for the GameBoard class. 
        /// Size constructor parameter sets the size of the board (default is 4x4). 
        /// the Grid property is a 2D array of Tile objects representing the game board.
        /// Boolean properties HasWon and HasLost indicate the game's win/loss state.
        /// </summary>
        public int Size { get; }
        public Tile[,] Grid { get; }
        public bool HasWon { get; private set; }
        public bool HasLost { get; private set; }

        /// <summary>
        /// GameBoard constructor initializes the game board with the specified size.
        /// </summary>
        /// <param name="size"></param>
        public GameBoard(int size = 4)
        {
            Size = size;
            Grid = new Tile[size, size];

            for (int r = 0; r < size; r++)
                for (int c = 0; c < size; c++)
                    Grid[r, c] = new Tile();

            AddRandomTile();
            AddRandomTile();
        }

        /// <summary>
        /// Move method processes a move in the specified direction.
        /// </summary>
        /// <param name="dir"></param>
        /// <returns></returns>
        public bool Move(Direction dir)
        {
            ResetMergeFlags();
            bool moved = false;

            for (int i = 0; i < Size; i++)
            {
                var line = GetLine(i, dir);
                var merged = MergeLine(line);
                moved |= SetLine(i, merged, dir);
            }

            if (moved)
            {
                AddRandomTile();
                CheckWin();
                CheckLose();
            }

            return moved;
        }

        /// <summary>
        /// Retrieves a list of tiles representing a single row or column from the grid in the specified direction.
        /// </summary>
        /// <remarks>The <paramref name="dir"/> parameter controls both the orientation and the order of
        /// the returned tiles: <list type="bullet">   <item>     <description>       <see cref="Direction.Left"/> and
        /// <see cref="Direction.Right"/> return a row at the specified <paramref name="index"/>.       <see
        /// cref="Direction.Left"/> returns tiles from left to right; <see cref="Direction.Right"/> returns tiles from
        /// right to left.     </description>   </item>   <item>     <description>       <see cref="Direction.Up"/> and
        /// <see cref="Direction.Down"/> return a column at the specified <paramref name="index"/>.       <see
        /// cref="Direction.Up"/> returns tiles from top to bottom; <see cref="Direction.Down"/> returns tiles from
        /// bottom to top.     </description>   </item> </list></remarks>
        /// <param name="index">The zero-based index of the row or column to retrieve. Must be within the valid range of the grid.</param>
        /// <param name="dir">The direction in which to traverse the grid. Determines whether a row or column is returned and the order of
        /// tiles.</param>
        /// <returns>A list of <see cref="Tile"/> objects representing the specified row or column in the requested order.</returns>
        /// <exception cref="ArgumentOutOfRangeException">Thrown if <paramref name="dir"/> is not a valid <see cref="Direction"/> value.</exception>
        private List<Tile> GetLine(int index, Direction dir)
        {
            var line = new List<Tile>();

            for (int i = 0; i < Size; i++)
            {
                line.Add(dir switch
                {
                    Direction.Left => Grid[index, i],
                    Direction.Right => Grid[index, Size - 1 - i],
                    Direction.Up => Grid[i, index],
                    Direction.Down => Grid[Size - 1 - i, index],
                    _ => throw new ArgumentOutOfRangeException()
                });
            }

            return line;
        }

        /// <summary>
        /// Updates a row or column of the grid with the specified line of tiles in the given direction.
        /// </summary>
        /// <remarks>This method replaces the entire <see cref="Tile"/> object at each position in the
        /// specified row or column if the value differs from the current tile. The direction parameter determines both
        /// which row or column is updated and the order in which tiles from <paramref name="line"/> are
        /// applied.</remarks>
        /// <param name="index">The zero-based index of the row or column to update. For horizontal directions (<see cref="Direction.Left"/>
        /// or <see cref="Direction.Right"/>), this is the row index; for vertical directions (<see
        /// cref="Direction.Up"/> or <see cref="Direction.Down"/>), this is the column index.</param>
        /// <param name="line">The list of <see cref="Tile"/> objects representing the new values to set for the specified row or column.
        /// The list must have a count equal to the grid size.</param>
        /// <param name="dir">The direction indicating which row or column to update and the order in which to apply the tiles. Must be
        /// one of <see cref="Direction.Left"/>, <see cref="Direction.Right"/>, <see cref="Direction.Up"/>, or <see
        /// cref="Direction.Down"/>.</param>
        /// <returns><see langword="true"/> if any tile in the specified row or column was changed; otherwise, <see
        /// langword="false"/>.</returns>
        private bool SetLine(int index, List<Tile> line, Direction dir)
        {
            bool changed = false;

            for (int i = 0; i < Size; i++)
            {
                // Determine the location
                int r = (dir == Direction.Left || dir == Direction.Right) ? index : (dir == Direction.Up ? i : Size - 1 - i);
                int c = (dir == Direction.Left || dir == Direction.Right) ? (dir == Direction.Left ? i : Size - 1 - i) : index;

                // Check if the value is different
                if (Grid[r, c].Value != line[i].Value)
                {
                    changed = true;
                    // CRITICAL CHANGE: Replace the entire object reference in the array
                    Grid[r, c] = new Tile(line[i].Value);
                }
            }

            return changed;
        }

        /// <summary>
        /// Merges a line of tiles according to 2048 game rules, combining adjacent tiles with equal values and shifting
        /// non-zero tiles to the front.
        /// </summary>
        /// <remarks>Adjacent tiles with the same non-zero value are combined into a single tile with
        /// double the value, and the resulting tile is placed at the position of the first tile in the pair. Only one
        /// merge occurs per pair per call. The method also updates the <c>HasWon</c> property to <see langword="true"/>
        /// if a tile with the value 2048 is created during the merge.</remarks>
        /// <param name="line">The list of <see cref="Tile"/> objects representing a single row or column to merge. The list must contain
        /// exactly <c>Size</c> elements.</param>
        /// <returns>A new list of <see cref="Tile"/> objects representing the merged line, with combined values and zeros
        /// appended as needed to maintain the original length.</returns>
        private List<Tile> MergeLine(List<Tile> line)
        {
            var values = line.Where(t => t.Value != 0).Select(t => t.Value).ToList();

            for (int i = 0; i < values.Count - 1; i++)
            {
                if (values[i] == values[i + 1])
                {
                    values[i] *= 2;
                    if (values[i] == 2048)
                        HasWon = true;

                    values.RemoveAt(i + 1);
                }
            }

            while (values.Count < Size)
                values.Add(0);

            return values.Select(v => new Tile(v)).ToList();
        }

        /// <summary>
        /// Resets the merge status of all tiles in the grid.
        /// </summary>
        /// <remarks>Sets the <c>IsMerged</c> property of each tile in the grid to <see
        /// langword="false"/>. Call this method before performing operations that require all tiles to be unmerged,
        /// such as starting a new move or turn.</remarks>
        private void ResetMergeFlags()
        {
            foreach (var tile in Grid)
                tile.IsMerged = false;
        }

        /// <summary>
        /// Adds a new tile with a value of 2 or 4 to a random empty position on the grid.
        /// </summary>
        /// <remarks>If there are no empty positions available on the grid, this method does nothing. The
        /// new tile will have a value of 2 in 90% of cases, or 4 in 10% of cases.</remarks>
        public void AddRandomTile()
        {
            var empty = new List<Tile>();

            foreach (var tile in Grid)
                if (tile.Value == 0)
                    empty.Add(tile);

            if (!empty.Any())
                return;

            var t = empty[Random.Shared.Next(empty.Count)];
            t.Value = Random.Shared.Next(10) == 0 ? 4 : 2;
        }

        /// <summary>
        /// Checks whether the current game state contains a winning tile.
        /// </summary>
        /// <remarks>This method updates the win status by determining if any tile in the grid has reached
        /// the target value required to win the game.</remarks>
        private void CheckWin()
        {
            HasWon |= Grid.Cast<Tile>().Any(t => t.Value == 2048);
        }

        /// <summary>
        /// Determines whether the current game state meets the conditions for a loss and updates the loss status
        /// accordingly.
        /// </summary>
        /// <remarks>This method checks if there are no available moves or empty tiles left on the grid.
        /// If no moves are possible and the grid is full, the <see cref="HasLost"/> property is set to <see
        /// langword="true"/> to indicate that the player has lost the game.</remarks>
        private void CheckLose()
        {
            if (Grid.Cast<Tile>().Any(t => t.Value == 0))
                return;

            foreach (var dir in Enum.GetValues<Direction>())
            {
                var clone = Clone();
                if (clone.Move(dir))
                    return;
            }

            HasLost = true;
        }

        /// <summary>
        /// Games a deep copy of the current game board.
        /// </summary>
        /// <returns></returns>
        private GameBoard Clone()
        {
            var clone = new GameBoard(Size);
            for (int r = 0; r < Size; r++)
                for (int c = 0; c < Size; c++)
                    clone.Grid[r, c].Value = Grid[r, c].Value;
            return clone;
        }

    }
    /// <summary>
    /// Enumeration representing the four possible movement directions in the 2048 game.
    /// </summary>
    public enum Direction
    {
        Left,
        Right,
        Up,
        Down
    }
}
