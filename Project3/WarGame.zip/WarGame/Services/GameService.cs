﻿using WarGame.Models;

namespace WarGame.Services
{
    /// <summary>
    /// Service to bridge what was coded in the models to the razor page to work smoothly. Handles the game logic.
    /// </summary>
    public class GameService
    {
        private Game game;

        public string CurrentPlayerName { get; set; }

        /// <summary>
        /// Constructor that sets ups the player names
        /// </summary>
        public GameService() 
        {
            var playerNames = new List<string> { "Player 1", "Player 2", "Player 3", "Player 4" };
            game = new Game(playerNames);
        }

        /// <summary>
        /// Method that sets up the game and puts the players' names in the game and sifts which one is currently playing.
        /// </summary>
        /// <param name="playerNames"></param>
        public void StartGame(List<string> playerNames) 
        {
            game = new Game(playerNames);
            CurrentPlayerName = playerNames.Count > 0 ? playerNames[0] : null;
        }

        /// <summary>
        /// Method that plays a round of the card game.
        /// </summary>
        public void PlayRound() 
        {
            if (game != null) 
            {
                game.PlayRound();
                NotifyStateChanged();
            }
        }

        public PlayerHands GetPlayerHands() => game.GetPlayerHands();
        public PlayedCards GetPlayedCards() => game.GetPlayedCards();

        /// <summary>
        /// Checks for the count of the players' hands
        /// </summary>
        /// <param name="playerName"></param>
        /// <returns></returns>
        public int GetPlayerHandCount(string playerName)
        {
            return game?.GetPlayerHands()?.GetHand(playerName)?.Count ?? 0;
        }

        public event Action OnChange;
        private void NotifyStateChanged() => OnChange?.Invoke();
    }
}
