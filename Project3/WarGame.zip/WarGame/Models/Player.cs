﻿namespace WarGame.Models
{
    /// <summary>
    /// Player class that gets their name and gets their hand. nothing much to see here lol.
    /// </summary>
    public class Player
    {
        public string Name { get; }
        public Hand Hand { get; }

        public Player(string name)
        {
            Name = name;
            Hand = new Hand();
        }

    }
}
