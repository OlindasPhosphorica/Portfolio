﻿namespace WarGame.Models
{
    /// <summary>
    /// Class to keep track of played cards.
    /// </summary>
    public class PlayedCards
    {
        /// <summary>
        /// distionary that gets the string and card, which is the suit and the rank.
        /// </summary>
        public Dictionary<string, Card> CardsInPlay { get; }

        /// <summary>
        /// constructor that implements keeping track of the cards in play with CardsInPlay
        /// </summary>
        public PlayedCards() 
        { 
            CardsInPlay = new Dictionary<string, Card>();
        }


        /// <summary>
        /// tells you whos playing what card they are playing.
        /// </summary>
        /// <param name="playerName"></param>
        /// <param name="card"></param>
        public void Add(string playerName, Card card) 
        {
            if (card != null)
            {
                CardsInPlay[playerName] = card;
            }
        }

        /// <summary>
        /// Clears all of the cards in play.
        /// </summary>
        public void Clear() 
        {
            CardsInPlay.Clear();
        }
    }
}
