﻿namespace WarGame.Models
{
    /// <summary>
    /// Represents a deck of playing cards that can be shuffled and drawn from.
    /// </summary>
    /// <remarks>The deck is initialized with 52 cards, each with a random rank and suit. There can be duplicates. Cards can be drawn
    /// from the deck until it is empty. The deck can also  distribute cards to players' hands.</remarks>
    public class Deck
    {
        /// <summary>
        /// Represents a collection of <see cref="Card"/> objects organized in a stack.
        /// </summary>
        /// <remarks>This stack is used to manage the order of <see cref="Card"/> objects, allowing
        /// operations such as pushing and popping cards. It is intended for internal use within the class to handle
        /// card-related operations.</remarks>
        private Stack<Card> cards;
        /// <summary>
        /// generates random numbers.
        /// </summary>
        /// <remarks>This instance of <see cref="Random"/> is used internally for generating random
        /// numbers in a thread-safe manner. It is not exposed for external use.</remarks>
        private static readonly Random random = new Random();

        /// <summary>
        /// Initializes a new instance of the <see cref="Deck"/> class.
        /// </summary>
        /// <remarks>This constructor creates a new deck of cards and initializes it with a standard set
        /// of playing cards.</remarks>
        public Deck() 
        {
            cards = new Stack<Card>();
            InitializeDeck();
        }

        /// <summary>
        /// Initializes the deck with a random set of 52 cards.
        /// </summary>
        /// <remarks>This method clears the current deck and populates it with a new set of 52 cards, each
        /// with a randomly selected rank and suit. The deck is shuffled as a result of the random selection
        /// process.</remarks>
        private void InitializeDeck() 
        {
            cards.Clear();

            Array ranks = Enum.GetValues(typeof(Card.Rank));
            Array suits = Enum.GetValues(typeof(Card.Suit));

            for (int i = 0; i < 52; i++) 
            {
                Card.Suit randomSuit = (Card.Suit)suits.GetValue(random.Next(suits.Length));
                Card.Rank randomRank = (Card.Rank)ranks.GetValue(random.Next(ranks.Length));

                cards.Push(new Card(randomSuit, randomRank));
            }
        }

        /// <summary>
        /// Draws a card from the top of the deck.
        /// </summary>
        /// <returns>The card drawn from the top of the deck, or returns null if the deck is empty.</returns>
        public Card DrawCard() 
        {
            if (cards.Count > 0) 
            {
                return cards.Pop();
            }
            return null;
        }

        /// <summary>
        /// Distributes the cards into the Player's Hand.
        /// </summary>
        /// <param name="playerHands"></param>
        /// <exception cref="ArgumentException"></exception>
         public void Distribute(PlayerHands playerHands) 
         {
            var playerNames = playerHands.GetPlayerNames().ToList();
            if (!playerNames.Any())
            {
                throw new ArgumentException("Player list cannot be null or empty.");
            }

            int playerIndex = 0;
            while (cards.Count > 0)
            {
                Card cardToDeal = DrawCard();
                string currentPlayerName = playerNames[playerIndex];

                playerHands.GetHand(currentPlayerName).AddCard(cardToDeal);

                playerIndex = (playerIndex + 1) % playerNames.Count;
            }

        }

    }
}
