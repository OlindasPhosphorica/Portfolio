﻿namespace WarGame.Models
{
    /// <summary>
    /// Hand class that handles method to generate a hand of playing cards.
    /// </summary>
    public class Hand
    {
        private Queue<Card> cards;
        public int Count => cards.Count;
        public Hand()
        {
            cards = new Queue<Card>();
        }
        
        /// <summary>
        /// Add Card method with an if argument that lets you enqueue from the card class. moves cards (the values) into the queue to be used.
        /// </summary>
        /// <param name="card"></param>
        public void AddCard(Card card) 
        {
            if (card != null) 
            {
                cards.Enqueue(card);
            }
        }

        /// <summary>
        /// After card is enqueued the method is used to actually add the cards to you hand.
        /// </summary>
        /// <param name="cardsToAdd"></param>
        public void AddCards(IEnumerable<Card> cardsToAdd) 
        {
            foreach (var card in cardsToAdd) 
            {
                AddCard(card);
            }
        }

        /// <summary>
        /// class that lets you play your card, unless your hand is empty.
        /// </summary>
        /// <returns></returns>
        public Card PlayCard() 
        {
            if (cards.Count > 0) 
            {
                return cards.Dequeue();
            }
            return null;
        }
    }
}
