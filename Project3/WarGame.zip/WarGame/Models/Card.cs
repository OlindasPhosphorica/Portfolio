﻿namespace WarGame.Models
{
    /// <summary>
    /// Represents a playing card with a suit and rank.
    /// </summary>
    /// <remarks>The <see cref="Card"/> class provides functionality to compare cards based on their rank and
    /// to represent the card as a string in the format "Rank of Suit".</remarks>
    public class Card : IComparable<Card>
    {
        /// <summary>
        /// Gets and sets the suit of the card and gets and sets the rank of the card
        /// </summary>
        public Suit CardSuit { get; set; }
        public Rank CardRank { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Card"/> class with the specified suit and rank.
        /// </summary>
        /// <param name="suit">The suit of the card. Must be a valid <see cref="Suit"/> enumeration value.</param>
        /// <param name="rank">The rank of the card. Must be a valid <see cref="Rank"/> enumeration value.</param>
        public Card(Suit suit, Rank rank)
        {
            CardSuit = suit;
            CardRank = rank;
        }
        /// <summary>
        /// Compares the current card with another card based on their ranks.
        /// </summary>
        /// <param name="other">The card to compare with the current card. Can be null.</param>
        /// <returns>A value indicating the relative order of the cards. Returns a positive integer if the current card's rank is
        /// greater, zero if the ranks are equal, or a negative integer if the current card's rank is less. Returns 1 if
        /// <paramref name="other"/> is null.</returns>
        public int CompareTo(Card? other)
        {
            if (other == null) return 1;
            return this.CardRank.CompareTo(other.CardRank);
        }
        /// <summary>
        /// Returns a string representation of the card, indicating its rank and suit.
        /// </summary>
        /// <returns>A string in the format "Rank of Suit", representing the card's rank and suit.</returns>
        public override string ToString()
        {
            return $"{CardRank} of {CardSuit}";
        }

        /// <summary>
        /// Represents the four suits in a standard deck of playing cards.
        /// </summary>
        public enum Suit
        {
            Hearts,
            Diamonds,
            Clubs,
            Spades
        }

        /// <summary>
        /// Represents the rank of a playing card in a standard deck.
        /// </summary>
        /// <remarks>The <see cref="Rank"/> enumeration defines the rank of a card, ranging from <see
        /// cref="Two"/> to <see cref="Ace"/>. Each rank is associated with a numerical value, which can be used for
        /// comparison or scoring purposes.</remarks>
        public enum Rank
        {
            Two = 2,
            Three = 3,
            Four = 4,
            Five = 5,
            Six = 6,
            Seven = 7,
            Eight = 8,
            Nine = 9,
            Ten = 10,
            Jack = 11,
            Queen = 12,
            King = 13,
            Ace = 14
        }
    }
}
