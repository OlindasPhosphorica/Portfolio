﻿namespace WarGame.Models
{
    /// <summary>
    /// Game class to handle the game logic
    /// </summary>
    public class Game
    {
        private PlayerHands playerHands;
        private PlayedCards playedCards;
        private Deck deck;

        /// <summary>
        /// Constructor to set up the game
        /// </summary>
        /// <param name="playerNames"></param>
        public Game(List<string> playerNames) 
        {
            playerHands = new PlayerHands(playerNames);
            playedCards = new PlayedCards();
            deck = new Deck();

            deck.Distribute(playerHands);
        }

        /// <summary>
        /// Play round method the handles playing a round of the card game.
        /// </summary>
        public void PlayRound() 
        {
            playedCards.Clear();
            var playersInRound = new List<string>(playerHands.GetPlayerNames());

            foreach (var playerName in playersInRound) 
            {
                Hand hand = playerHands.GetHand(playerName);
                if (hand.Count > 0) 
                {
                    playedCards.Add(playerName, hand.PlayCard());
                }
            }
            DetermineRoundWinner();
        }

        /// <summary>
        /// Method that determines the round winner. 
        /// </summary>
        private void DetermineRoundWinner() 
        {
            if (!playedCards.CardsInPlay.Any()) 
            {
                Console.WriteLine("No cards were played this round.");
                return;
            }

            var winnerEntry = playedCards.CardsInPlay
                .OrderByDescending(entry => entry.Value.CardRank)
                .FirstOrDefault();

            var winners = playedCards.CardsInPlay
                .Where(entry => entry.Value.CardRank == winnerEntry.Value.CardRank)
                .ToList();

            if (winners.Count == 1) 
            {
                var winnerName = winnerEntry.Key;
                var winningHand = playerHands.GetHand(winnerName);

                winningHand.AddCards(playedCards.CardsInPlay.Values);
                System.Console.WriteLine($"{winnerName} wins the round and gets {playedCards.CardsInPlay.Count} cards.");
            }

            else
            {
                 System.Console.WriteLine("It's a tie! Starting a war...");
            }
        }

        public PlayerHands GetPlayerHands() => playerHands;
        public PlayedCards GetPlayedCards() => playedCards;
    }
}
