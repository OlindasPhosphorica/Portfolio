﻿namespace WarGame.Models
{
    /// <summary>
    /// PlayerHands class to keep track of who's playing what.
    /// </summary>
    public class PlayerHands
    {
        private Dictionary<string, Hand> hands;

        /// <summary>
        /// Allows for playernames to be added next to their hand so you know who has what.
        /// </summary>
        /// <param name="playerNames"></param>
        public PlayerHands(IEnumerable<string> playerNames)
        {
            hands = new Dictionary<string, Hand>();
            foreach (var name in playerNames)
            {
                hands[name] = new Hand();
            }
        }

        public Hand GetHand(string playerName) => hands[playerName];
        public IEnumerable<string> GetPlayerNames() => hands.Keys;
    }
}
