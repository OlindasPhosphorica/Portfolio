﻿namespace Project2Manual.Services
{
    /// <summary>
    /// Model Player class that inherits from ICharacter interface. Id and type are used for website.
    /// </summary>
    public class Player : ICharacter
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public string Symbol { get; set; }
        public string Description { get; set; }
        public int Id { get; set; }
        public string Type => "character";
    }
}
