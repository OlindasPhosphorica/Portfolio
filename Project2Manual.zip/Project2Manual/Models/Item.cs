﻿namespace Project2Manual.Services
{
    //As you saw in my previous project, this was an abstract class. I've already learned that abstract classes are the devil, so I did my research and it seems for this project it would be better off as an interface.
    /// <summary>
    /// Item interface used for Healthpot and Weapon.
    /// </summary>
    public interface Item
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Symbol { get; set; }
        public float HealthVal { get; set; }
        public int Id { get; set; }
        public string Type { get;}
    }
}
