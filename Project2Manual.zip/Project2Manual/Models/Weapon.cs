﻿namespace Project2Manual.Services
{
    /// <summary>
    /// Model weapon class that inherits from Item interface. Id and type used for website.
    /// </summary>
    public class Weapon : Item 
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Symbol { get; set; }
        public float HealthVal { get; set; }
        public int Id { get; set; }
        public string Type => "Weapon";
        public int Damage { get; set; }

    }
}
