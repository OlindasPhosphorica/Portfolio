﻿namespace Project2Manual.Services
{
    /// <summary>
    /// Model class named Healthpot that inherits from the Item interface. Id and type are used to display these as references on the website.
    /// </summary>
    public class HealthPot : Item
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Symbol { get; set; }
        public float HealthVal { get; set; }
        public int Id { get; set; }
        public string Type => "health potion";


    }
}
