﻿namespace Project2Manual.Services
{
    /// <summary>
    /// Model monster class that inherits from Icharacter interface. Id and type are used for the website.
    /// </summary>
    public class Monster : ICharacter
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public string Symbol { get; set; }
        public string Description { get; set; }
        public int Damage { get; set; }
        public int Id { get; set; }
        public string Type => "Monster";
    }
}
