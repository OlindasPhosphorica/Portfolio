﻿namespace Project2Manual.Services
{
    /// <summary>
    /// ICharacter interface used for Player and Monster model classes.
    /// </summary>
    public interface ICharacter
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public string Symbol { get; set; }
        public string Description { get; set; }
        public int Id { get; set; }
        public string Type { get; }
    
    }
}
