﻿namespace Project2Manual.Models
{
    /// <summary>
    /// Model note class that sets up the id of the note, as well as the title, content, references, and createddate.
    /// </summary>
    public class Note
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public DateTime CreatedDate { get; set; } = DateTime.Now;
        public List<Reference> References { get; set; } = new List<Reference>();
    }
}
