﻿namespace Project2Manual.Models
{
    /// <summary>
    /// reference class with type, Id, and name identifiers. Used to input references of the player, monster, healthpot, and weapon into the website.
    /// </summary>
    public class Reference
    {
        public string? Type { get; set; } 
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
