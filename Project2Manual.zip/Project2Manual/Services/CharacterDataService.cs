﻿namespace Project2Manual.Services
{
    public class CharacterDataService
    {
        /// <summary>
        /// A service that assigns a List from the Icharacter interface to the method GetCharacters()
        /// </summary>
        /// <returns></returns>
        public List<ICharacter> GetCharacters() 
        {
            return new List<ICharacter>
            {
                new Player {Id = 1, Name = "Player1", Health = 100, Symbol = "The symbol is the letter P", Description = "The adventerous explorer of this maze." },
                new Monster {Id = 2, Name = "Ogre", Health = 80, Symbol = "The symbol is the letter M", Description = "The derisive ogre that hates visitors.", Damage = 20},
            };
        }
    }
}
