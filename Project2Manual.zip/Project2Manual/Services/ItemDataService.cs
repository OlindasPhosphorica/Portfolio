﻿namespace Project2Manual.Services
{
    public class ItemDataService
    {
        /// <summary>
        /// A service that gets a list from the abstract item class and puts into to GetItems method
        /// </summary>
        /// <returns></returns>
        public List<Item> GetItems()
        {
            return new List<Item>
            {
                new Weapon { Id = 1, Name = "Giant Axe", Description = "A ridiculously large axe, it's insane you can pick it up let alone swing it. The health Value for the weapone is tied to how long you can use it before it breaks.", Symbol = "The symbol is the letter W", HealthVal = 80, Damage = 20},
                new HealthPot { Id = 2, Name = "Health Potion", Description = "Restores health when consumed.", Symbol = "The symbol is the letter H", HealthVal = 50 },
            };
        }
    }
}
