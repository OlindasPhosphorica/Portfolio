﻿using Project2Manual.Components.Pages;
using Project2Manual.Models;

namespace Project2Manual.Services
{
    public class NoteService
    {
        /// <summary>
        /// A service that gets a list from the note class, and putting it into the GetNotes method.
        /// </summary>

        private List<Note> _notes = new List<Note>();

        public List<Note> GetNotes()
        {
            return _notes;
        }
        /// <summary>
        /// AddNote method that adds another note.
        /// </summary>
        /// <param name="newNote"></param>
        public void AddNote(Note newNote) 
        {
            _notes.Add(newNote); 
        }

        /// <summary>
        /// A SaveNote method that takes the existing note and then saves the title, content, and the reference. if exisitng note isn't null, proceed with saving the note.
        /// </summary>
        /// <param name="note"></param>
        public void SaveNote(Note note)
        {
            var existingNote = _notes.FirstOrDefault(n => n.Id == note.Id);
            if (existingNote != null)
            {
                existingNote.Title = note.Title;
                existingNote.Content = note.Content;
                existingNote.References = note.References;
            }
        }
        /// <summary>
        /// DeleteNote method that deletes the note. Identifies the note to delete using int id. if notetoremove isn't null, proceed with deleting the note.
        /// </summary>
        /// <param name="id"></param>
        public void DeleteNote(int id)
        {
            var noteToRemove = _notes.FirstOrDefault(n => n.Id == id);
            if (noteToRemove != null)
            {
                _notes.Remove(noteToRemove);
            }
        }

    }
}
